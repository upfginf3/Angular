import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { EnfantComponent } from './enfant/enfant.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, EnfantComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {
  title = 'inout';
  montantP = 1000;

  depot() {
    this.montantP += 100;
  }
  recevoirMontant(m: number) {
    this.montantP = m;
  }
}
