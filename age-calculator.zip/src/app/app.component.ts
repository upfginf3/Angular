import { Component } from '@angular/core';
import { AgeFormComponent } from './age-form/age-form.component';
import { Age } from './Age';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  imports: [AgeFormComponent, CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {
  title = 'age-calculator';
  age?: Age | null;

  getBirthDayDate(age: Age) {
    this.age = age;
  }
}
