import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Output } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { Age } from '../Age';

@Component({
  selector: 'app-age-form',
  imports: [CommonModule, FormsModule],
  templateUrl: './age-form.component.html',
  styleUrl: './age-form.component.css',
})
export class AgeFormComponent {
  years = '';
  months = '';
  days = '';

  age?: Age;
  @Output() ageEmit: EventEmitter<Age> = new EventEmitter();

  onSubmit() {
    this.calculerAge();
    this.ageEmit.emit(this.age);
    //form.resetForm();
  }

  calculerAge() {
    let birthDay = Number(this.days);
    let birthMonth = Number(this.months); // mois au format 1-12
    let birthYear = Number(this.years);

    const today = new Date();
    const birthDate = new Date(birthYear, birthMonth - 1, birthDay);

    let ageYears = today.getFullYear() - birthDate.getFullYear();
    let ageMonths = today.getMonth() - birthDate.getMonth();
    let ageDays = today.getDate() - birthDate.getDate();

    // Corriger si le jour actuel est avant le jour de naissance
    if (ageDays < 0) {
      ageMonths--;
      const previousMonth = new Date(today.getFullYear(), today.getMonth(), 0); // dernier jour du mois précédent
      ageDays += previousMonth.getDate();
    }

    // Corriger si le mois actuel est avant le mois de naissance
    if (ageMonths < 0) {
      ageYears--;
      ageMonths += 12;
    }

    this.age = {
      years: ageYears,
      months: ageMonths,
      days: ageDays,
    };
  }
}
