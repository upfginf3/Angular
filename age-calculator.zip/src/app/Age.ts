export interface Age {
  days: number;
  months: number;
  years: number;
}
