import { Component } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { TeamService } from '../team.service';

@Component({
  selector: 'app-team',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './team.component.html',
  styleUrl: './team.component.css',
})
export class TeamComponent {
  member?: any;
  //name?: string | null;
  constructor(
    private route: ActivatedRoute,
    private teamService: TeamService
  ) {}

  getTeamMember(id: number) {
    return this.teamService.team.filter((t) => t.id == id)[0];
  }

  ngOnInit() {
    this.route.paramMap.subscribe((params) => {
      let id: number = Number(params.get('id'));
      let name = params.get('name');
      console.log(name);
      this.member = this.getTeamMember(id);
    });
  }

  /* ngOnInit() {
    let id: number = this.route.snapshot.params['id'];
    //let id: number = Number(this.route.snapshot.paramMap.get('id'));
    this.member = this.getTeamMember(id);
  } */

  /* ngDoCheck() {
    //let id: number = this.route.snapshot.params['id'];
    let id: number = Number(this.route.snapshot.paramMap.get('id'));
    this.member = this.getTeamMember(id);
  } */
}
