import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  public loggedIn = false;
  public role = 'user';

  constructor() {}
}
