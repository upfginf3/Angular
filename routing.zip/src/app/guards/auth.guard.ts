import { inject } from '@angular/core';
import {
  CanActivateChildFn,
  CanActivateFn,
  CanDeactivateFn,
  Router,
} from '@angular/router';
import { AuthService } from '../auth.service';
import { AccesDeniedComponent } from '../acces-denied/acces-denied.component';

export const authGuard: CanActivateFn = (route, state) => {
  if (inject(AuthService).loggedIn) return true;
  else {
    inject(Router).navigate(['/access-denied']);
    return false;
  }
};

export const authChildGuard: CanActivateChildFn = (route, state) => {
  if (inject(AuthService).loggedIn && inject(AuthService).role === 'admin')
    return true;
  else {
    inject(Router).navigate(['/access-denied']);
    return false;
  }
};

export const desactivateGuard: CanDeactivateFn<AccesDeniedComponent> = (
  component: AccesDeniedComponent
) => {
  if (inject(AuthService).loggedIn) return true;
  else {
    alert('You must be logged on to exit the page');
    return false;
  }
};
