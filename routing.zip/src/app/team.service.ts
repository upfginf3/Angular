import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class TeamService {
  team: any[] = [
    {
      id: 1,
      name: 'Sara Doe',
      img: 'https://placehold.co/400x300?text=Sara Doe',
      role: 'Founder',
      skills: [
        { skill: 'Sales', comp: '90%' },
        { skill: 'Communication', comp: '70%' },
        { skill: 'Leadership', comp: '80%' },
        { skill: 'Planning', comp: '90%' },
        { skill: 'Management', comp: '80%' },
      ],
    },
    {
      id: 2,
      name: 'Joe Doke',
      img: 'https://placehold.co/400x300?text=Joe Doke',
      role: 'Founder',
      skills: [
        { skill: 'SAP', comp: '90%' },
        { skill: 'ERP', comp: '70%' },
        { skill: 'CRM', comp: '85%' },
        { skill: 'Project Management', comp: '90%' },
        { skill: 'Databases', comp: '80%' },
        { skill: 'Data Analysis', comp: '60%' },
      ],
    },
    {
      id: 3,
      name: 'Cun Lee',
      img: 'https://placehold.co/400x300?text=Cun Lee',
      role: 'Designer',
      skills: [
        { skill: 'Photoshop', comp: '95%' },
        { skill: 'Premiere Pro', comp: '95%' },
        { skill: 'Illustrator', comp: '90%' },
        { skill: 'Indesign', comp: '95%' },
      ],
    },
    {
      id: 4,
      name: 'Andy Col',
      img: 'https://placehold.co/400x300?text=Andy Col',
      role: 'Developer',
      skills: [
        { skill: 'HTML', comp: '95%' },
        { skill: 'CSS', comp: '95%' },
        { skill: 'JQuery', comp: '90%' },
        { skill: 'PHP', comp: '95%' },
      ],
    },
  ];
  constructor() {}
}
