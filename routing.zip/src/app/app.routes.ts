import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import {
  authGuard,
  authChildGuard,
  desactivateGuard,
} from './guards/auth.guard';

export const routes: Routes = [
  { path: 'home', component: HomeComponent, title: 'Home' },
  {
    path: 'contact',
    component: ContactComponent,
    title: 'Contact Us',
  },
  {
    path: 'about',
    component: AboutComponent,
    title: 'About Us',
    children: [
      {
        path: 'services',
        loadComponent: () =>
          import('./services/services.component').then(
            (m) => m.ServicesComponent
          ),
        title: 'About | Services',
      },

      {
        path: 'team/:id/:name',

        loadComponent: () =>
          import('./team/team.component').then((m) => m.TeamComponent),
        title: 'About | Team Member',
      },

      {
        path: 'team/:id',
        loadComponent: () =>
          import('./team/team.component').then((m) => m.TeamComponent),
        title: 'About | Team Member',
      },
    ],
  },
  {
    path: 'dashboard',
    loadComponent: () =>
      import('./dashboard/dashboard.component').then(
        (m) => m.DashboardComponent
      ),
    canActivate: [authGuard],
    canActivateChild: [authChildGuard],
    title: 'Dashboard',
    children: [
      {
        path: 'users',
        loadComponent: () =>
          import('./dashboard/users/users.component').then(
            (m) => m.UsersComponent
          ),
      },
    ],
  },
  {
    path: 'access-denied',
    loadComponent: () =>
      import('./acces-denied/acces-denied.component').then(
        (m) => m.AccesDeniedComponent
      ),
    canDeactivate: [desactivateGuard],
  },
  /* {
    path: 'about/team/:id',
    loadComponent: () =>
      import('./team/team.component').then((m) => m.TeamComponent),
    //component: TeamComponent,
    title: 'About | Team Member',
  }, */
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  {
    path: '**',
    loadComponent: () =>
      import('./page404/page404.component').then((m) => m.Page404Component),
    title: 'Page Not Found',
  },
];
