import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { AuthService } from './auth.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {
  title = '8-routing';

  constructor(private auth: AuthService) {}
  login() {
    this.auth.loggedIn = true;
    this.auth.role = 'user';
    //this.auth.role = 'admin';
    alert('You are logged in : ' + this.auth.role);
  }

  isAuth() {
    return this.auth.loggedIn;
  }

  logout() {
    alert('You are logged out');
    this.auth.loggedIn = false;
    this.auth.role = 'user';
  }
}
