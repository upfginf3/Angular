import { Component, inject } from '@angular/core';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { TeamService } from '../team.service';

@Component({
  selector: 'app-about',
  standalone: true,
  imports: [RouterLink, RouterOutlet],
  templateUrl: './about.component.html',
  styleUrl: './about.component.css',
})
export class AboutComponent {
  team: any[] = [];
  constructor(private teamService: TeamService, private router: Router) {}
  ngOnInit() {
    this.team = this.teamService.team;
  }
  goToServices() {
    this.router.navigate(['about/services']);
  }
}
