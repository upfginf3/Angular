import { Component } from '@angular/core';

@Component({
  selector: 'app-acces-denied',
  standalone: true,
  imports: [],
  templateUrl: './acces-denied.component.html',
  styleUrl: './acces-denied.component.css'
})
export class AccesDeniedComponent {

}
