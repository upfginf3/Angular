import { Component, EventEmitter, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-number-choice',
  imports: [FormsModule],
  templateUrl: './number-choice.component.html',
  styleUrl: './number-choice.component.css',
})
export class NumberChoiceComponent {
  num: number = 1;
  @Output() numChange = new EventEmitter<number>();

  reinitialiser() {
    this.num = 1;
    this.numChange.emit(this.num);
  }

  sendvalue() {
    if (this.num < 1 || isNaN(this.num)) this.num = 1;
    this.numChange.emit(this.num);
  }
}
