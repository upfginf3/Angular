import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-multiplication-table',
  imports: [],
  templateUrl: './multiplication-table.component.html',
  styleUrl: './multiplication-table.component.css',
})
export class MultiplicationTableComponent {
  @Input({ required: true }) num!: number;
  urlImg = 'https://placehold.co/400x150?text=';
  numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

  createTableMultiplication(): number[] {
    return this.numbers.map((x) => x * this.num);
  }
}
