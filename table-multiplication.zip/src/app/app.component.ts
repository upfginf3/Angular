import { Component } from '@angular/core';
import { NumberChoiceComponent } from './number-choice/number-choice.component';
import { MultiplicationTableComponent } from './multiplication-table/multiplication-table.component';

@Component({
  selector: 'app-root',
  imports: [NumberChoiceComponent, MultiplicationTableComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {
  title = 'table-multiplication';
  n = 1;

  receiveNumber(nombre: number) {
    this.n = nombre;
  }
}
