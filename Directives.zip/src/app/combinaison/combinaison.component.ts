import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

type UserType = {
  readonly id: number;
  name: string;
  isActive: boolean;
  additionalInfo: string;
  status?: 'active' | 'inactive' | '';
};

@Component({
  selector: 'app-combinaison',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './combinaison.component.html',
  styleUrl: './combinaison.component.css',
})
export class CombinaisonComponent {
  users: UserType[] = [
    {
      id: 1,
      name: 'Alice',
      isActive: true,
      additionalInfo: 'Others Infos',
      status: 'active',
    },
    {
      id: 2,
      name: 'Bob',
      isActive: false,
      additionalInfo: 'Nothing',
      status: 'inactive',
    },
    {
      id: 3,
      name: 'Charlie',
      isActive: true,
      additionalInfo: 'Nothing',
      status: '',
    },
  ];
}
