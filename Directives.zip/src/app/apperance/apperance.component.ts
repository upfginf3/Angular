import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { CustomDirective } from '../custom.directive';

@Component({
  selector: 'app-apperance',
  standalone: true,
  imports: [CommonModule, CustomDirective],
  templateUrl: './apperance.component.html',
  styleUrl: './apperance.component.css',
})
export class ApperanceComponent {
  clr: string = 'white';
  withBG = true;

  changeColor() {
    this.withBG = !this.withBG;
    if (this.withBG) this.clr = 'white';
    else this.clr = '#00FF00';
  }
}
