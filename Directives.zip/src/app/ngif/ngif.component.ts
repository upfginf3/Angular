import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-ngif',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './ngif.component.html',
  styleUrl: './ngif.component.css',
})
export class NgifComponent {
  show: boolean = true;
  genre: string = '';

  showHide() {
    this.show = !this.show;
  }

  estHomme() {
    return this.genre === 'homme' ? true : false;
  }
}
