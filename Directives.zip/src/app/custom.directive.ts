import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[appCustom]',
  standalone: true,
})
export class CustomDirective {
  constructor(private element: ElementRef) {}
  ngOnInit() {
    this.element.nativeElement.style.fontSize = 24 + 'px';
    this.element.nativeElement.style.border = '2px solid black';
    this.element.nativeElement.style.fontFamily = 'consolas';
  }
}
