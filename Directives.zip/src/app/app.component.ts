import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { NgifComponent } from './ngif/ngif.component';
import { NgforComponent } from './ngfor/ngfor.component';
import { NgswitchComponent } from './ngswitch/ngswitch.component';
import { CombinaisonComponent } from './combinaison/combinaison.component';
import { ApperanceComponent } from './apperance/apperance.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    RouterOutlet,
    NgifComponent,
    NgforComponent,
    NgswitchComponent,
    CombinaisonComponent,
    ApperanceComponent,
  ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {
  title = '5-directives';
}
