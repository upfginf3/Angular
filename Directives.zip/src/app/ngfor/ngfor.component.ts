import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-ngfor',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './ngfor.component.html',
  styleUrl: './ngfor.component.css',
})
export class NgforComponent {
  users: any[] = [
    { name: 'Sam', age: 45, id: 1 },
    { name: 'Jim', age: 33, id: 2 },
    { name: 'Ana', age: 17, id: 3 },
    { name: 'Lou', age: 4, id: 4 },
  ];

  add() {
    let newIndex = this.users.length + 1;
    this.users = this.users.map((obj) => {
      return Object.assign({}, obj);
    });
    this.users.push({ name: `Test${newIndex}`, age: 15, id: newIndex });
  }
}
