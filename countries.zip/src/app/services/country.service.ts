import { Injectable } from '@angular/core';
import { Country } from '../country';

@Injectable({
  providedIn: 'root',
})
export class CountryService {
  countries: Country[] = [];

  async getCountries(region: string, search: string) {
    const response = await fetch('https://restcountries.com/v3.1/all');
    this.countries = await response.json();
    this.countries = this.countries.filter((c) => c.name.common !== 'Israel');
    if (region !== 'FiltredByRegion') {
      this.countries = this.countries.filter((c) => c.region == region);
    }
    if (search != '') {
      this.countries = this.countries.filter((c) =>
        //c.name.common.toLowerCase().includes(search.toLowerCase())
        c.name.common.toLowerCase().startsWith(search.toLowerCase())
      );
    }
    return this.countries;
  }
}
