import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CountriesListComponent } from './countries-list/countries-list.component';

@Component({
  selector: 'app-root',
  imports: [CountriesListComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {
  title = 'countries-g2';
}
