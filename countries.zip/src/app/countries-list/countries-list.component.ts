import { Component, inject } from '@angular/core';
import { Country } from '../country';
import { CommonModule } from '@angular/common';
import { CountryCardComponent } from '../country-card/country-card.component';
import { FormsModule } from '@angular/forms';
import { CountryService } from '../services/country.service';

@Component({
  selector: 'app-countries-list',
  imports: [CommonModule, CountryCardComponent, FormsModule],
  templateUrl: './countries-list.component.html',
  styleUrl: './countries-list.component.css',
})
export class CountriesListComponent {
  private cs = inject(CountryService);
  //constructor(private cs: CountryService) {}
  countries: Country[] = [];
  regions: string[] = [
    'Africa',
    'Americas',
    'Antarctic',
    'Asia',
    'Europe',
    'Oceania',
  ];
  region = 'FiltredByRegion';
  search = '';

  async getCountries() {
    this.countries = await this.cs.getCountries(this.region, this.search);
  }

  ngOnInit() {
    this.getCountries();
  }

  selectByRegion() {
    this.getCountries();
  }

  selectByText() {
    this.getCountries();
  }
}
