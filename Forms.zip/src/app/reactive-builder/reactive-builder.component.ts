import { Component, inject } from '@angular/core';
import {
  FormGroup,
  Validators,
  FormBuilder,
  ReactiveFormsModule,
} from '@angular/forms';
import { rangeValidator } from '../reactive/reactive.component';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-reactive-builder',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './reactive-builder.component.html',
  styleUrl: './reactive-builder.component.css',
})
export class ReactiveBuilderComponent {
  public myForm!: FormGroup;
  private fb: FormBuilder = inject(FormBuilder);

  constructor() {}
  ngOnInit() {
    this.myForm = this.fb.group({
      firstname: ['', [Validators.required, Validators.minLength(2)]],
      lastname: ['', [Validators.required, Validators.minLength(2)]],
      age: ['', [Validators.required, Validators.min(1), Validators.max(100)]],
      city: [''],
      zip: [
        '',
        [
          Validators.required,
          Validators.pattern('^[0-9]*$'),
          rangeValidator(20, 80),
        ],
      ],
      agree: [false],
    });
  }

  onSubmit() {
    if (this.myForm.valid) {
      console.log(this.myForm);
      console.log('Form Data:', this.myForm.value);
      console.log(
        'Full name:',
        this.myForm.value.firstname + ' ' + this.myForm.value.lastname
      );
    } else {
      console.log('Form is not valid');
    }
  }
}
