import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { RangeValidatorDirective } from './range-validator.directive';

@Component({
  selector: 'app-template-driven',
  standalone: true,
  imports: [RangeValidatorDirective, FormsModule, CommonModule],
  templateUrl: './template-driven.component.html',
  styleUrl: './template-driven.component.css',
})
export class TemplateDrivenComponent {
  firstname: string = '';
  lastname: string = '';
  age?: number;
  city: string = '';
  zip: string = '';
  agree: boolean = false;

  onSubmit(form: NgForm) {
    console.log(form.form);
    console.log('Form Data:', form.value);
    console.log('Full name:', form.value.firstname + ' ' + form.value.lastname);
  }
}
