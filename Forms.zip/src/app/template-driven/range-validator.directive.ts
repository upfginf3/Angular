import { Directive, Input } from '@angular/core';
import {
  AbstractControl,
  NG_VALIDATORS,
  ValidationErrors,
  Validator,
} from '@angular/forms';

@Directive({
  selector: '[rangeValidator]',
  standalone: true,
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: RangeValidatorDirective,
      multi: true,
    },
  ],
})
export class RangeValidatorDirective implements Validator {
  @Input('rangeValidator') range!: { min: number; max: number };
  validate(control: AbstractControl): ValidationErrors | null {
    const value = control.value;
    if (value === null || value === undefined || isNaN(value)) {
      return null;
    }
    if (value < this.range.min || value > this.range.max) {
      return { range: true }; // erreur renvoyée
    }
    return null;
  }
}
