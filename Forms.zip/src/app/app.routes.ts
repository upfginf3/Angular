import { Routes } from '@angular/router';
import { ReactiveComponent } from './reactive/reactive.component';
import { TemplateDrivenComponent } from './template-driven/template-driven.component';
import { ReactiveBuilderComponent } from './reactive-builder/reactive-builder.component';

export const routes: Routes = [
  {
    path: 'template-driven',
    component: TemplateDrivenComponent,
  },
  {
    path: 'reactive',
    component: ReactiveComponent,
  },
  {
    path: 'fbuilder',
    component: ReactiveBuilderComponent,
  },

  {
    path: '',
    redirectTo: 'template-driven',
    pathMatch: 'full',
  },
];
