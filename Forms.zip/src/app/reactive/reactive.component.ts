import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import {
  AbstractControl,
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  ValidationErrors,
  ValidatorFn,
  Validators,
} from '@angular/forms';

export function rangeValidator(min: number, max: number): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    if (control.value < min || control.value > max) {
      return { range: true };
    }
    return null;
  };
}

@Component({
  selector: 'app-reactive',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './reactive.component.html',
  styleUrl: './reactive.component.css',
})
export class ReactiveComponent {
  public myForm!: FormGroup;
  formsubmited: boolean = false;

  constructor() {}
  ngOnInit() {
    this.myForm = new FormGroup({
      firstname: new FormControl(''),
      lastname: new FormControl('', [
        Validators.required,
        Validators.minLength(2),
      ]),
      age: new FormControl('', [
        Validators.required,
        Validators.min(1),
        Validators.max(100),
      ]),
      city: new FormControl(''),
      zip: new FormControl('', [
        Validators.required,
        Validators.pattern('^[0-9]*$'),
        rangeValidator(20, 80),
      ]),
      agree: new FormControl(),
    });
  }

  onSubmit() {
    this.formsubmited = true;
    console.log(this.myForm);
    console.log('Form Data:', this.myForm?.value);
    console.log(
      'Full name:',
      this.myForm?.value.firstname + ' ' + this.myForm?.value.lastname
    );
  }
}
