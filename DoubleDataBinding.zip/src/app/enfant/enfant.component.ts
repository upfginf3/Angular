import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-enfant',
  standalone: true,
  imports: [],
  templateUrl: './enfant.component.html',
  styleUrl: './enfant.component.css',
})
export class EnfantComponent {
  @Input() montant: number = 0;
  @Output() montantChange: EventEmitter<number> = new EventEmitter<number>();

  retrait() {
    this.montant -= 100;
    this.montantChange.emit(this.montant);
  }
}
