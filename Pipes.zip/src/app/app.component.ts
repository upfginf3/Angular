import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { SubstringPipe } from './substring.pipe';

@Component({
  selector: 'app-root',
  standalone: true,
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
  imports: [RouterOutlet, CommonModule, SubstringPipe],
  providers: [],
})
export class AppComponent {
  title = 'Exemples dEs PiPes';
  today = new Date();
  personne = { name: 'Test', age: 15, id: 1 };
  names = ['Toto', 'Jojo', 'Mimi', 'Lili'];
}
