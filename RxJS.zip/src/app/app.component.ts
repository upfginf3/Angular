import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { TestObservableComponent } from './test-observable/test-observable.component';
import { TestOperatorsComponent } from './test-operators/test-operators.component';
import { TestSubjectComponent } from './test-subject/test-subject.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    RouterOutlet,
    TestObservableComponent,
    TestOperatorsComponent,
    TestSubjectComponent,
  ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {
  title = '9-RxJS';
}
