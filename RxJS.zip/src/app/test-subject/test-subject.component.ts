import { Component } from '@angular/core';
import { BehaviorSubject, ReplaySubject, Subject } from 'rxjs';

@Component({
  selector: 'app-test-subject',
  standalone: true,
  imports: [],
  templateUrl: './test-subject.component.html',
  styleUrl: './test-subject.component.css',
})
export class TestSubjectComponent {
  ngOnInit() {
    /* const subject = new Subject();
    subject.subscribe((x) => console.log('Observer 1: ' + x));
    subject.subscribe((x) => console.log('Observer 2: ' + x));
    subject.next(1);
    subject.next(2);
    subject.subscribe((x) => console.log('Observer 3: ' + x));
    subject.next(3); */
    /* const subject = new BehaviorSubject<any>('initial value');
    subject.subscribe((x) => console.log('Observer 1: ' + x));
    subject.next(1);
    subject.next(2);
    subject.subscribe((x) => console.log('Observer 2: ' + x));
    subject.next(3);
    subject.next(4);
    subject.next(5);
    subject.subscribe((x) => console.log('Observer 3: ' + x));
    subject.next(6);
    subject.complete(); */
    const subject = new ReplaySubject(4);
    subject.next(1);
    subject.next(2);
    subject.next(3);
    subject.subscribe((x) => console.log(x));
    subject.next(4);
    subject.next(5);
    subject.next(6);
    subject.complete();
  }
}
