import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { from, of, interval, range, timer, merge, Observable } from 'rxjs';
import { ajax } from 'rxjs/ajax';

@Component({
  selector: 'app-test-observable',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './test-observable.component.html',
  styleUrl: './test-observable.component.css',
})
export class TestObservableComponent {
  source$!: Observable<number>;

  ajaxSource$!: Observable<any>;

  users: any;

  ngOnInit() {
    // Constructeur Observable
    /* this.source$ = new Observable((observer) => {
      observer.next(1);
      observer.next(2);
      observer.next(3);
      observer.next(4);
      observer.next(5);
      observer.complete();
    });
    this.source$.subscribe((value) => {
      console.log(value);
    }); */
    // Fonctions créant un Observable
    //
    this.source$ = from([1, 2, 3, 4, 5]);
    //this.source$ = of(1, 2, 3, 4, 5);
    //this.source$ = interval(3000); // envoie une valeur chaque 1s
    //this.source$ = range(4, 3);
    //this.source$ = timer(10000, 2000); // envoie une valeur chaque 2s apres 10s
    //this.source$ = timer(3000); // envoie une seule valeur apres 3s
    /* this.source$.subscribe((value) => {
      console.log('Sub2 ' + value);
    }); */
    // Merge Observables
    /* const source2$ = range(6, 4);
    const merged$ = merge(this.source$, source2$);
    merged$.subscribe((value) => console.log(value)); */
    // Ajax Observable
    /* this.ajaxSource$ = ajax({
      url: 'https://jsonplaceholder.typicode.com/users',
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
      responseType: 'json',
    });

    this.ajaxSource$.subscribe((value) => {
      console.log(value.response);
      this.users = value.response;
    }); */
    // S'abonner à l'Observable
    /* this.source$.subscribe((value) => {
      console.log(value);
    });
    
    // S'abonner et gérer les erreurs et la fin de l'Observable
    this.source$.subscribe({
      next: (value) => console.log(value),
      error: (error) => console.log(error),
      complete: () => console.log('complete'),
    }); */
    // gérer les abonnements
    /* this.source$ = interval(1000);
    const subscription = this.source$.subscribe((value) => {
      console.log(value);
    });

    this.source$.subscribe((value) => {
      console.log(value);
    });
    setTimeout(() => {
      subscription.unsubscribe();
    }, 10000); */
  }
}
