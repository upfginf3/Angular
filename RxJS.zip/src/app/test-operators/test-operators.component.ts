import { Component } from '@angular/core';
import {
  Observable,
  of,
  from,
  concat,
  interval,
  race,
  zip,
  forkJoin,
  tap,
  delay,
  fromEvent,
} from 'rxjs';
import { ajax } from 'rxjs/ajax';
import {
  buffer,
  defaultIfEmpty,
  distinct,
  elementAt,
  every,
  filter,
  finalize,
  find,
  first,
  isEmpty,
  last,
  map,
  mergeMap,
  reduce,
  repeat,
  scan,
  sequenceEqual,
  skip,
  skipWhile,
  take,
  takeUntil,
  takeWhile,
  toArray,
} from 'rxjs/operators';
@Component({
  selector: 'app-test-operators',
  standalone: true,
  imports: [],
  templateUrl: './test-operators.component.html',
  styleUrl: './test-operators.component.css',
})
export class TestOperatorsComponent {
  ngOnInit() {
    // Constructeur Observable
    let source$ = new Observable<number>((observer) => {
      observer.next(1);
      observer.next(2);
      observer.next(3);
      observer.next(4);
      observer.next(5);
      //observer.next(-2);
      observer.complete();
    });

    /* source$
      .pipe(
        tap((value) => {
          value *= 3;
          console.log(value);
        })
      )
      .subscribe((value) => {
        console.log(value);
      }); */

    // Trandform Operators
    /* source$.pipe(map((value) => value * 3)).subscribe((value) => {
      console.log(value);
    }); */

    /* source$
      .pipe(reduce((acc, x) => acc + x, 0))
      .subscribe((x) => console.log(x)); */

    /* source$.pipe(scan((acc, x) => acc * x, 1)).subscribe((x) => console.log(x)); */

    /* source$.pipe(toArray()).subscribe((val) => console.log(val)); */

    // Filter Operators
    /* source$.pipe(filter((value) => value >= 3)).subscribe((value) => {
      console.log(value);
    }); */

    /* const users$ = of(
      { name: 'John', age: 31 },
      { name: 'Jane', age: 25 },
      { name: 'Bob', age: 40 }
    ); */

    /* const users$ = from([
      { name: 'John', age: 21 },
      { name: 'Jane', age: 25 },
      { name: 'Bob', age: 40 },
    ]);

    users$.pipe(find((user) => user.age > 30)).subscribe((value) => {
      console.log(value);
    }); */

    // take
    /* source$.pipe(take(3)).subscribe((value) => {
      console.log(value);
    }); */

    // takeWhile
    /* source$.pipe(takeWhile((value) => value <= 3)).subscribe((value) => {
      console.log(value);
    }); */

    //source$.pipe(first()).subscribe((x) => console.log(x));
    //source$.pipe(last()).subscribe((x) => console.log(x));
    //source$.pipe(elementAt(0)).subscribe((val) => console.log(val));
    //source$.pipe(skip(2)).subscribe((x) => console.log(x));
    // source$.pipe(skipWhile((x) => x < 3)).subscribe((x) => console.log(x));

    // Condition Operators
    /* source$.pipe(every((value) => value >= 0)).subscribe((value) => {
      console.log(value);
    }); */

    /* source$ = of();
    source$
      .pipe(defaultIfEmpty('Valeur par défaut'))
      .subscribe((val) => console.log(val)); */

    /* source$ = of();
    source$.pipe(isEmpty()).subscribe((val) => console.log(val)); */

    /* source$ = of(1, 2, 3);
    const source2$ = of(1, 2, 3);
    source$.pipe(sequenceEqual(source2$)).subscribe((val) => console.log(val)); */

    // Combine Operators
    /* const observable1 = of(1, 2, 3);
    const observable2 = of(4, 5, 6);
    concat(observable1, observable2).subscribe((val) => {
      console.log(val);
    }); */

    /* const obs1 = interval(3000).pipe(take(10));
    const obs2 = interval(10000).pipe(take(5));
    const obs3 = interval(15000).pipe(take(8));
    race(obs1, obs2, obs3).subscribe({
      next: (value) => console.log(value),
      error: (error) => console.log(error),
      complete: () => console.log('Complete!'),
    }); */

    /* const observable1 = of(1, 2, 3, 4);
    const observable2 = of('a', 'b', 'c', 'd', 'e');
    const combined = zip(observable1, observable2);
    combined.subscribe((val) => console.log(val)); */

    /* const userData = ajax('https://jsonplaceholder.typicode.com/users');
    const repoData = ajax('https://jsonplaceholder.typicode.com/posts').pipe(
      delay(5000)
    );
    forkJoin([userData, repoData]).subscribe((results) => {
      const user = results[0].response;
      const repos = results[1].response;
      console.log(user);
      console.log(repos);
    }); */

    // Utile Operators
    /* const source = interval(1000);
    const example = source.pipe(take(3), repeat(2));
    //const example = source.pipe(take(3)).pipe(repeat(2));
    example.subscribe((val) => console.log(val)); */

    /* const myObservable = of(1, 2, 3).pipe(
      finalize(() => {
        console.log('Observable completed!');
      })
    );
    myObservable.subscribe((val) => console.log(val)); */
  }
}
